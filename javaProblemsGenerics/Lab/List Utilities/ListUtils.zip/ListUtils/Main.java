package ListUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IllegalAccessException {


    //    List<Integer> numbers = Arrays.asList(3, 6, 1, 0, 5);

      //  System.out.println(ListUtils.getMax(numbers));
        //System.out.println(ListUtils.getMin(numbers));

    List<Integer>integers = new ArrayList<>();
        Collections.addAll(integers, 1,2,18,2,-1);
    }
}
